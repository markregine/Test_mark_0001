# test_mark_0001
This is a first attempt to use git and pipy to manage a hypertheticla module i want to build

### I used the following websites to build a module and publish it to pipy.
* #### https://pythonhosted.org/foo-test/minimal.html
* #### https://docs.python.org/3/distutils/setupscript.html
* #### https://packaging.python.org/tutorials/packaging-projects/
